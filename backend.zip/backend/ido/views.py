from django.shortcuts import render
from rest_framework import viewsets
from .serializers import IdoSerializer
from .models import Ido

# Create your views here.
class IdoView(viewsets.ModelViewSet):
    serializer_class = IdoSerializer
    queryset = Ido.objects.all()
