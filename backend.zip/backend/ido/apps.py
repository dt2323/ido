from django.apps import AppConfig


class IdoConfig(AppConfig):
    name = 'ido'
