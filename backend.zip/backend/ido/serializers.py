from rest_framework import serializers
from .models import Ido

class IdoSerializer(serializers.ModelSerializer):
    class Meta:
        model = Ido
        fields = ('id', 'title', 'description', 'completed')
